Everything in this dir is experimental and hacky.

To use things from here, drag them to the root dir.

Use at your own risk :P

``Comparisons directory``: contains sample data to test outputs against from charles v1, along with a customized test set.

``modded-bulk-inference.py`` will create responses, in bulk, using my scoring.

``modded-inference`` is an interactive inference environemnt, with scoring. 

``scoring.py`` contains score rules.

